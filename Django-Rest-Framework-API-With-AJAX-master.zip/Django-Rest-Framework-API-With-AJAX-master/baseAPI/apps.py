from django.apps import AppConfig


class BaseapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'baseAPI'
